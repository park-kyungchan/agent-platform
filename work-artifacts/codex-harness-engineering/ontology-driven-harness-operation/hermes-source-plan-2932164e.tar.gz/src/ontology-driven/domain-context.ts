export * from '@palantirkc/native-hermes-adapter/ontology-driven/domain-context';

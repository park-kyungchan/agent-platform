export * from '@palantirkc/native-hermes-adapter/ontology-driven/current-intent';

export * from '@palantirkc/native-hermes-adapter/ontology-driven/role-registry';

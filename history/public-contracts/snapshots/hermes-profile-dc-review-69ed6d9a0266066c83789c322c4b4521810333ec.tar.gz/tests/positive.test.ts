import {test,expect} from 'bun:test';
import {createHash} from 'node:crypto';
const hashText=(text:string)=>createHash('sha256').update(text).digest('hex');
import {SourceCoverage} from '../src/review/source-coverage.ts';
import {readHandoff,validSummary} from '../src/review/handoff-contract.ts';
import {reviewFixture} from './review-fixture.ts';
test('positive: exact Unicode page coverage and complete handoff are structurally consumable',()=>{
 const f=reviewFixture();const issues:string[]=[];const coverage=new SourceCoverage(f.packet,f.expected,(ok,code)=>{if(!ok)issues.push(code);});
 coverage.read(f.args,f.page);expect(coverage.finish()).toEqual([{documentId:'synthetic-document',coveredChars:3,totalChars:3}]);expect(issues).toEqual([]);
 const input={verdict:'NO_VERDICT',findings:['Synthetic source requires an owner decision.'],limits:['Fixture only.']};const output=readHandoff(input,true)!;expect(output.verdict).toBe('NO_VERDICT');output.findings.push('caller mutation');expect(input.findings).toHaveLength(1);expect(validSummary('😀'.repeat(6000))).toBe(true);
});
import {assessReview} from '../src/review-evidence.ts';
test('positive: exact synthetic trace establishes reader evidence, not semantic acceptance',()=>{
 const f=reviewFixture();const r=assessReview(f.packet,f.expected,f.observation);expect(r.status).toBe('COMPLETE_READER_EVIDENCE');expect(r.verdict).toBe('revise');expect(r.pageReads).toBe(1);expect(r.issues).toEqual([]);
});

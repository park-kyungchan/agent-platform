import {assessReview} from '../src/review-evidence.ts';
import {reviewFixture} from '../tests/review-fixture.ts';
const f=reviewFixture();const result=assessReview(f.packet,f.expected,f.observation);
if(result.status!=='COMPLETE_READER_EVIDENCE')throw Error('Unexpected consumer result');
console.log(JSON.stringify({synthetic:true,status:result.status,verdict:result.verdict,acceptance:'not_established'}));

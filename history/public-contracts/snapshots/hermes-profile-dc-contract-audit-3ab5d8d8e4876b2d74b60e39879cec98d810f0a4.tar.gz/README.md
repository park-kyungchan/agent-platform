# Adversarial contract auditor

Classification: documentation-and-contract-examples. Previously published source history is retained; current affected-source acceptance is withdrawn. R6 is a local corrective candidate pending fresh independent exact-source review before any corrective publication.

Challenge authority, state transitions, failure accounting, evidence bindings and false completion using supplied records.

Preserve gaps and disputed claims for the actual accepting owner; do not fabricate independent filesystem access.

This package contains selected existing pure TypeScript contracts, not a native profile export, full agent implementation, deployed product or replacement canonical registry. The three evidence-role packages are documentation and contract examples, not claims of separate product traction.

## Run

Use Bun 1.4.1. Runtime build, tests and example require no dependency installation. Run `bun --no-env-file run build`, `bun --no-env-file run test:positive`, `bun --no-env-file run test:negative` and `bun --no-env-file run example`. For type checking, install the pinned development dependencies with `bun install --frozen-lockfile --ignore-scripts`, then run `bun --no-env-file run check`. Existing read-only tools may instead be selected with `TSC_PATH` and `TS_TYPE_ROOTS`; no toolchain is copied.

## Boundaries

R6 is the current corrective public derivative, implementing a fresh user-selected PUBLIC rule, not private canonical meaning adoption: each confirmed supersession requires a current source anchor outside the union of all directly and transitively superseded revisions of the same decision identity. A-to-B-to-A replay and merging only historical A/B sources reject with SUPERSESSION_NEEDS_NEW_SOURCE. Genuinely new C evidence must still match supplied source bytes; a new descriptor alone is not confirmation. Synthetic future fixtures are separate from the user's policy confirmation and contain no real native records.

R5 protections remain intact: contradictory same-occurrence content claims reject before supersession novelty. Selected predecessor lineage is verified against supplied rows and keeps inherited evidence gaps. The byte-identical reviewed R4 finite own-data snapshot protects all included intent, discovery/result, coverage and handoff seams, refusing getters, caller iterators, decoration and custom prototypes before domain reads. Coverage binds a detached frozen private constructor pin. This bundle does not include a native trace assessor, and none is added by R6. Hostile Proxy traps and global runtime mutation remain excluded; no native JSON authentication, fully safe OS, delivered native API or teacher acceptance is established. Original extraction pins and private originals are unchanged.

R2 is an owner-prepared PUBLIC_DERIVATIVE, not a canonical repair. PUBLICPROVENANCE.json preserves each original source pin and records the changed public digest and bounded delta; PROVENANCE.json's file entries describe the original extraction. Run `bun --no-env-file run test` for the complete suite, including R2 regressions. Intent object APIs reject sparse and inherited list indices; JSON text cannot encode holes. Clarification responses enter through JSON strings, not direct array objects. Reader page/index shapes reject unsupported annotations before coverage; known source labels and totals remain evidence metadata, never native permission. This package does not include the legacy review trace assessor.

All fixtures are newly authored synthetic records. No provider calls, native filesystem access, native store queries, dispatch, execution grants, installed profile changes or external effects are implemented. Current native restrictions remain unchanged. In particular, source review route declarations are not current tool exposure, and supplied-evidence roles do not gain filesystem access. Source identities and byte matches do not establish authenticity, completeness, understanding, freshness, model quality or owner acceptance.

The context resolver returns NO_EXECUTION_AUTHORITY even when RESOLVED. Historical authorization and proposals do not become current confirmed direction. Review coverage checks caller-supplied page records; they do not read source files, attest a real session, or enforce an OS sandbox. Review handoff validity is not a proof of a correct verdict.

The legacy review-evidence API (where included) retains its original reader name and schema; it is a pure evidence consumer, not the current native plugin. Unknown annotations and native restrictions must not be interpreted as granted access.

## Lineage and rights

PROVENANCE.json records exact hashes of the copied seams without private filesystem bindings. Role documentation is a selected view of the shared role source, not a new role registry. Vendored copies are pinned, owner-prepared small seams so each candidate works independently after separate repository publication. They do not supersede the owner's sources.

Original source rights are reserved; see LICENSE. Dependency packages retain their own licenses; none are bundled. No private history, source captures, real learner data, native credentials, session snapshots, current Work or operational configuration is included.
